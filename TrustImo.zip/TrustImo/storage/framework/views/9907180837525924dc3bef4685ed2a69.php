<?php $__env->startSection('title', 'Propriétés'); ?>

<?php $__env->startSection('base'); ?>

    <!-- Navbar Start -->
    <div class="container-fluid nav-bar bg-transparent mb-5">
        <nav class="navbar navbar-expand-lg bg-white navbar-light py-0 px-4">
            <a href="index.html" class="navbar-brand d-flex align-items-center text-center">
                <div class="icon p-2 me-2">
                    <img class="img-fluid" src="../assets/img/logo_Trust Imo.png" alt="Icon" style="width: 85px; height: 90px;">
                </div>
                <h1 class="m-0 text-primary">TrustImo</h1>
            </a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto">
                    <a href="" class="nav-item nav-link"> <i class="fa fa-bell p-1"></i> Notifications</a>
                </div>
                <a href="" class="btn btn-primary px-3 py-2 my-2 d-lg-flex"><i class="fa fa-user p-1"></i>Pofil</a>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

<div class="container-fluid bg-white p-0">
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->



    <!-- Property List Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="row g-0 align-items-center">
                <div class="col-lg- text-start d-flex justify-content-between text-lg-center wow slideInRight" data-wow-delay="0.1s">
                    <a href="" class="rounded-5 px-2 d-lg-flex" ><i class="fa fa-arrow-left"></i></a>
                    <ul class="nav nav-pills d-inline-flex justify-content-center mb-5">
                        <li class="nav-item me-2">
                            <a class="btn btn-outline-primary active" href="<?php echo e(route('properties.listing')); ?>">Propriétés</a>
                        </li>
                        <li class="nav-item me-0">
                            <a class="btn btn-outline-primary" href="<?php echo e(route('parcelles.listing')); ?>">Parcelles</a>
                        </li>
                    </ul>
                </div>
            </div>



            <div class="tab-content">
                <div id="tab-1" class="tab-pane fade show p-0 active">

                    <!-- Search Start -->
                    <div class="container-fluid bg-primary mb-5 wow fadeIn" data-wow-delay="0.1s" style="padding: 35px;">
                        <div class="container">
                                <form class="row g-2" action="" method="GET">
                                    <div class="col-md-10">
                                        <div class="row g-2">
                                            <div class="col-md-4">
                                                <input type="text" value="<?php echo e($input['title'] ?? ''); ?>" name="title" class="form-control border-0 py-3" placeholder="Mot clé">
                                            </div>
                                            <div class="col-md-4">
                                                <input type="number" value="<?php echo e($input['price'] ?? ''); ?>" name="price" class="form-control border-0 py-3" placeholder="Budget Max (f CFA)">
                                            </div>
                                            <div class="col-md-4">
                                                <input type="text" value="<?php echo e($input['city'] ?? ''); ?>" name="city" class="form-control border-0 py-3" placeholder="Ville">
                                            </div>
                                            <div class="col-md-4">
                                                <input type="number" value="<?php echo e($input['surface'] ?? ''); ?>" name="surface" class="form-control border-0 py-3" placeholder="Superficie minimun (m²)">
                                            </div>
                                            <div class="col-md-4">
                                                <select name="type" class="form-select border-0 py-3">
                                                    <option selected value="<?php echo e($input['type'] ?? ''); ?>"><?php echo e($input['type'] ?? 'Type de Propriété'); ?></option>
                                                    <option value="1">Property Type 1</option>
                                                    <option value="2">Property Type 2</option>
                                                    <option value="3">Property Type 3</option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <select name="operation" class="form-select border-0 py-3">
                                                    <option selected value="<?php echo e($input['operation'] ?? ''); ?>"><?php echo e($input['operation'] ?? 'Location/Vente'); ?></option>
                                                    <option value="Location">Location</option>
                                                    <option value="Vente">Vente</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-dark border-0 w-100 py-3">Rechercher</button>
                                    </div>
                                </form>
                        </div>
                    </div>
                    <!-- Search End -->

                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <div class="col-lg-4 col-md-6">
                                <div class="property-item rounded overflow-hidden">
                                    <div class="position-relative overflow-hidden">
                                        <a href="<?php echo e(route('properties.details', [$property, 'slug' => $property->getSlug()])); ?>"><img class="img-fluid" src="../assets/img/property-1.jpg" alt=""></a>
                                        <div class="bg-primary rounded text-white position-absolute start-0 top-0 m-4 py-1 px-3"><?php echo e($property->type); ?></div>
                                        <div class="bg-white rounded-top text-primary position-absolute start-0 bottom-0 mx-4 pt-1 px-3"><?php echo e($property->name); ?></div>
                                    </div>
                                    <div class="p-4 pb-0">
                                        <h5 class="text-primary mb-3"><?php echo e(number_format($property->loyé, thousands_separator: ' ')); ?> fCFA</h5>
                                        <a class="d-block h5 mb-2" href="<?php echo e(route('properties.details',[$property, 'slug' => $property->getSlug()])); ?>"><?php echo e($property->name); ?></a>
                                        <p><i class="fa fa-map-marker-alt text-primary me-2"></i><?php echo e($property->ville); ?>, <?php echo e($property->quartier); ?></p>
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-ruler-combined text-primary me-2"></i><?php echo e($property->surface); ?> m²</small>
                                        <small class="flex-fill text-center py-2"><i class="fa fa-bath text-primary me-2"></i><?php echo e($property->rooms); ?> Pièce(s)</small>
                                        <small class="flex-fill text-center border-end py-2"><i class="fa fa-bed text-primary me-2"></i><?php echo e($property->bedrooms); ?> Chambre(s)</small>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="alert alert-warning text-center" role="alert">
                                Aucune correspondance dans notre base de données!!
                                Contactez notre agence pour avoir le service spéciale Chasseur
                            </div>
                        <?php endif; ?>
                        <div class="col-12 text-center">
                            <?php echo e($properties->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Property List End -->





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kyge/Documents/TrustImo/resources/views/User/listing.blade.php ENDPATH**/ ?>