<?php $__env->startSection('auth'); ?>

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Propriétés Enregistrées</h1>
            <a href="<?php echo e(route('get_add_house')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-plus fa-sm text-white-50"></i>Ajouter une Propriétée</a>
        </div>

                                        <!-- DataTales Example -->
                                        <div class="card shadow mb-4">
                                            <div class="card-header py-3">
                                                <h6 class="m-0 font-weight-bold text-success">Liste des Propriétés Enregistrées</h6>
                                            </div>
                                            <div class="card-body col">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                                        <thead>
                                                            <tr>
                                                                <th>Nom</th>
                                                                <th>Type</th>
                                                                <th>Ville</th>
                                                                <th>Quartier/ <br>Village</th>
                                                                <th>Prix/Loyé</th>
                                                                <th>Avance</th>
                                                                <th>Pièces</th>
                                                                <th>Chambres</th>
                                                                <th>Date de publication</th>
                                                                <th>Status</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tfoot>
                                                            <tr>
                                                                <th>Nom</th>
                                                                <th>Type</th>
                                                                <th>Ville</th>
                                                                <th>Quartier/ <br>Village</th>
                                                                <th>Prix/Loyé</th>
                                                                <th>Avance</th>
                                                                <th>Pièces</th>
                                                                <th>Chambres</th>
                                                                <th>Date de publication</th>
                                                                <th>Status</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </tfoot>
                                                        <tbody>

                                                            <?php $__currentLoopData = $maisons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maison): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <tr class="col-12">
                                                                <td><?php echo e($maison->name); ?></td>
                                                                <td><?php echo e($maison->type); ?></td>
                                                                <td><?php echo e($maison->ville); ?></td>
                                                                <td><?php echo e($maison->quartier); ?></td>
                                                                <td><?php echo e($maison->loyé); ?></td>
                                                                <td><?php echo e($maison->avance); ?></td>
                                                                <td><?php echo e($maison->rooms); ?></td>
                                                                <td><?php echo e($maison->bedrooms); ?></td>
                                                                <td><?php echo e($maison->created_at); ?></td>
                                                                <td><?php echo e($maison->status); ?></td>
                                                                <td class="d-flex">
                                                                    <a href="<?php echo e(route('edit_house', ['id' => $maison->id])); ?>" class="d-none m-2 d-sm-inline-block btn btn-sm btn-warning shadow-sm"><i
                                                                        class="fas fa-edit fa-lg text-white-70"></i></a>
                                                                    <a href="<?php echo e(route('delete_house', ['id' => $maison->id])); ?>" class="d-none m-2 d-sm-inline-block btn btn-sm btn-danger shadow-sm"><i
                                                                            class="fas fa-trash fa-lg text-white-70"></i></a>
                                                                </td>
                                                            </tr>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>


                <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kyge/Documents/TrustImo/resources/views/Admin/Maisons/maisons.blade.php ENDPATH**/ ?>